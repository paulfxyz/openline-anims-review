/* ══ /multiple-tier1 · "The Data Stock Market" (cyan system) ══════════ */

import { mk, INK, WHITE, GRAY, LINE, GREEN, GREEN_SOFT, GREEN_TEXT, RED, pill, icon } from './kit.js';

const K = mk('cyan');
const { P, wrap, dots, bloom, mono, label, num, card, panel, badge, MONO } = K;

const pMK = (t = 'OMDM market') => [pill('cyan', `${icon('trend')}${t}`, { top: '14px', left: '14px' })];

/* deterministic pseudo-random series so every render looks the same */
const series = (n, seed = 7, lo = 0.56, hi = 1.32) => {
  const out = [];
  let v = (lo + hi) / 2;
  for (let i = 0; i < n; i++) {
    const r = Math.sin(seed * (i + 1) * 12.9898) * 43758.5453;
    const f = r - Math.floor(r);
    v += (f - 0.5) * 0.22;
    v = Math.max(lo, Math.min(hi, v));
    out.push(v);
  }
  return out;
};

/* ══════════════ 0 · CURRENT ══════════════ */
export const mkCurrent = {
  id: 'mk-current',
  name: 'Current',
  family: 'Live today',
  tagline: 'One frozen bar chart with a BUY tag',
  desc: 'A card reading "wholesale data · live", a price of $0.94/GB, a green −34% badge and eight bars with one highlighted and tagged BUY. It is the right idea — a market, a dip, a purchase — but the chart never moves, so "trades this market 24/7" is contradicted by a still image, and the single BUY tag reads as a label rather than an event.',
  pros: ['The market metaphor is already correct and on-brand', 'A single price and a single discount are easy to grasp'],
  cons: ['Labelled "live" while nothing updates — the weakest kind of claim', 'One BUY tag cannot show a strategy, only a moment', 'Eight plain bars carry no time axis, so there is no sense of history', 'The saving is asserted in a badge rather than demonstrated'],
  scores: { story: 3, motion: 2, perf: 5, mobile: 4, brand: 4, ease: 5 },
  build: (uid) => {
    const vals = [0.62, 0.86, 0.72, 1.0, 0.58, 0.8, 0.94, 0.78];
    const base = 350, maxH = 170;
    const inner = `
    ${dots(uid)}
    ${bloom(320, 250, 200, uid)}
    ${panel(64, 96, 512, 288)}
    ${mono(94, 132, 'WHOLESALE DATA · LIVE', { size: 9.5, op: 0.4 })}
    <text x="94" y="170" font-size="30" font-weight="700" fill="${INK}" style="font-family:${MONO}">$0.94</text>
    ${label(186, 170, '/GB', { size: 15, op: 0.45 })}
    <g transform="translate(452 144)">
      <rect width="94" height="30" rx="15" fill="${GREEN_SOFT}"/>
      <text x="47" y="20" text-anchor="middle" font-size="13" font-weight="700" fill="${GREEN_TEXT}" style="font-family:${MONO}">↗ -34%</text>
    </g>
    ${vals.map((v, i) => {
      const h = v * maxH;
      const x = 98 + i * 54;
      const on = i === 6;
      return `<rect x="${x}" y="${base - h}" width="42" height="${h}" rx="4"
        fill="${on ? P.main : P.soft}" opacity="${on ? 1 : 0.85}"/>
        ${on ? `<g transform="translate(${x + 21} ${base - h - 18})">
          <rect x="-20" y="-13" width="40" height="24" rx="6" fill="${INK}"/>
          <text y="4" text-anchor="middle" font-size="9.5" font-weight="700" fill="${WHITE}" style="font-family:${MONO}">BUY</text>
        </g>` : ''}`;
    }).join('')}
    <line x1="94" y1="${base}" x2="546" y2="${base}" stroke="${LINE}" stroke-width="2"/>
    ${label(94, 372, 'Our AI buys at the dip — and the saving reaches your price.', { size: 12.5, op: 0.5, weight: 600 })}`;
    return { svg: wrap(inner), pills: pMK() };
  },
};

/* ══════════════ 1 · LIVE CANDLES ══════════════ */
export const candles = {
  id: 'mkcandles',
  name: 'Live Candles',
  family: 'Trading floor',
  tagline: 'A real market tape, streaming',
  desc: 'A candlestick chart streams right to left with the price label following the last close, green and red bodies, and a BUY flag that drops on genuine local lows with the fill price beside it. A running "average fill" figure sits under the chart. If the section is going to call this a stock market, this is what a stock market looks like.',
  pros: ['Immediately recognisable as a live market — the metaphor lands with no copy', 'Continuous streaming means the panel is never still', 'BUY flags on actual troughs prove the strategy, not just the intent', 'Red candles make the volatility real, which makes the saving meaningful'],
  cons: ['Introduces red into the cyan palette', 'Candlesticks assume a little financial literacy', 'Most complex of the five to build'],
  scores: { story: 5, motion: 5, perf: 4, mobile: 3, brand: 4, ease: 3 },
  build: (uid) => {
    const inner = `
    ${dots(uid)}
    ${bloom(320, 230, 210, uid)}
    ${panel(40, 74, 560, 312)}
    ${mono(66, 108, 'OMDM · WHOLESALE DATA · LIVE', { size: 9.5, op: 0.4 })}
    <text x="66" y="146" font-size="28" font-weight="700" fill="${INK}" style="font-family:${MONO}"><tspan data-role="cprice">$0.94</tspan></text>
    ${label(158, 146, '/GB', { size: 14, op: 0.42 })}
    <g transform="translate(468 120)">
      <rect width="108" height="30" rx="15" fill="${GREEN_SOFT}"/>
      <text x="54" y="20" text-anchor="middle" font-size="12.5" font-weight="700" fill="${GREEN_TEXT}"
        style="font-family:${MONO}"><tspan data-role="cchg">↗ -34%</tspan></text>
    </g>
    <g transform="translate(66 170)">
      ${[0, 1, 2, 3].map(i => `<line x1="0" y1="${i * 42}" x2="510" y2="${i * 42}" stroke="${LINE}" stroke-width="1" stroke-dasharray="3 6"/>`).join('')}
      <svg width="510" height="176" viewBox="0 0 510 176" overflow="hidden">
        <g data-cwrap></g>
      </svg>
    </g>
    <line x1="66" y1="348" x2="576" y2="348" stroke="${LINE}" stroke-width="2"/>
    ${mono(66, 372, 'AVERAGE FILL', { size: 9, op: 0.35 })}
    <text x="168" y="374" font-size="13" font-weight="700" fill="${P.deep}" style="font-family:${MONO}"><tspan data-role="cfill">$0.61/GB</tspan></text>
    ${mono(576, 372, 'YOUR PRICE NEVER MOVES', { size: 9.5, op: 0.35, anchor: 'end' })}`;

    return {
      svg: wrap(inner),
      pills: pMK('Trading 24/7'),
      init(root) {
        const wrapEl = root.querySelector('[data-cwrap]');
        if (!wrapEl) return null;
        const NS = 'http://www.w3.org/2000/svg';
        const priceEl = root.querySelector('[data-role="cprice"]');
        const chgEl = root.querySelector('[data-role="cchg"]');
        const fillEl = root.querySelector('[data-role="cfill"]');
        const N = 26, CW = 19.6, H = 176;
        const lo = 0.5, hi = 1.4;
        const yOf = v => H - ((v - lo) / (hi - lo)) * (H - 16) - 8;
        let data = series(N, 11).map(v => v);
        let fills = [];
        const draw = () => {
          wrapEl.innerHTML = '';
          data.forEach((c, i) => {
            const o = i ? data[i - 1] : c;
            const up = c >= o;
            const wickHi = Math.max(c, o) + 0.05, wickLo = Math.min(c, o) - 0.05;
            const x = i * CW + CW / 2;
            const w = document.createElementNS(NS, 'line');
            w.setAttribute('x1', x); w.setAttribute('x2', x);
            w.setAttribute('y1', yOf(wickHi)); w.setAttribute('y2', yOf(wickLo));
            w.setAttribute('stroke', up ? '#EF4444' : P.main);
            w.setAttribute('stroke-width', '1.4');
            w.setAttribute('opacity', '0.6');
            wrapEl.appendChild(w);
            const b = document.createElementNS(NS, 'rect');
            const top = yOf(Math.max(c, o)), bot = yOf(Math.min(c, o));
            b.setAttribute('x', x - 6); b.setAttribute('width', '12');
            b.setAttribute('y', top); b.setAttribute('height', String(Math.max(3, bot - top)));
            b.setAttribute('rx', '2');
            b.setAttribute('fill', up ? '#EF4444' : P.main);
            b.setAttribute('opacity', up ? '0.75' : '1');
            wrapEl.appendChild(b);
          });
          fills.forEach(f => {
            const i = f.i;
            if (i < 0) return;
            const x = i * CW + CW / 2;
            const g = document.createElementNS(NS, 'g');
            g.setAttribute('transform', `translate(${x} ${yOf(data[i]) + 22})`);
            g.innerHTML = `<path d="M 0 -12 L 5 -4 L -5 -4 Z" fill="${INK}"/>
              <rect x="-26" y="-4" width="52" height="20" rx="5" fill="${INK}"/>
              <text y="10" text-anchor="middle" font-size="9" font-weight="700" fill="#FFFFFF"
                style="font-family:ui-monospace,Menlo,monospace">$${data[i].toFixed(2)}</text>`;
            wrapEl.appendChild(g);
          });
        };
        const tick = () => {
          const last = data[data.length - 1];
          let v = last + (Math.random() - 0.5) * 0.24;
          v = Math.max(0.54, Math.min(1.34, v));
          data.push(v); data.shift();
          fills = fills.map(f => ({ i: f.i - 1 })).filter(f => f.i >= 0);
          // buy on a local low
          const n = data.length;
          if (n > 3 && data[n - 2] < data[n - 3] && v > data[n - 2] && data[n - 2] < 0.78) {
            fills.push({ i: n - 2 });
            if (fills.length > 2) fills.shift();
            if (fillEl) fillEl.textContent = `$${(data[n - 2] * 0.99).toFixed(2)}/GB`;
          }
          if (priceEl) priceEl.textContent = `$${v.toFixed(2)}`;
          if (chgEl) chgEl.textContent = `↗ -${(26 + Math.round(Math.random() * 14))}%`;
          draw();
        };
        draw();
        const id = setInterval(tick, 900);
        return () => clearInterval(id);
      },
    };
  },
};

/* ══════════════ 2 · DIP HUNTER ══════════════ */
export const dipHunter = {
  id: 'mkdip',
  name: 'Dip Hunter',
  family: 'Narrative',
  tagline: 'Watch the AI wait, then buy',
  desc: 'A single smooth price line scrolls past while a cyan marker rides along it. When the line bottoms out the marker flashes, a ring fires, and a "bought" chip drops with the price — then a savings total climbs in the corner. It has the clearest cause and effect of the five: the price fell, so we bought, so you paid less.',
  pros: ['One line, one marker — the simplest possible reading of the story', 'The buy moment is an event with a beginning and an end', 'A climbing savings total is the benefit, not the mechanism', 'Reads perfectly at phone width'],
  cons: ['A smooth line looks less like a real market than candles do', 'Only shows one series, so it cannot show the spread or the alternatives'],
  scores: { story: 5, motion: 5, perf: 5, mobile: 5, brand: 5, ease: 4 },
  build: (uid) => {
    const inner = `
    ${dots(uid)}
    ${bloom(320, 230, 200, uid)}
    ${panel(40, 78, 560, 304)}
    ${mono(66, 112, 'WHOLESALE PRICE · LAST 24H', { size: 9.5, op: 0.4 })}
    <text x="66" y="150" font-size="28" font-weight="700" fill="${INK}" style="font-family:${MONO}"><tspan data-role="dprice">$0.94</tspan></text>
    ${label(158, 150, '/GB', { size: 14, op: 0.42 })}
    <g transform="translate(414 124)">
      <rect width="162" height="32" rx="16" fill="${GREEN_SOFT}"/>
      <text x="81" y="21" text-anchor="middle" font-size="12" font-weight="700" fill="${GREEN_TEXT}"
        style="font-family:${MONO}"><tspan data-role="dsave">SAVED $0.00/GB</tspan></text>
    </g>
    <g transform="translate(66 176)">
      ${[0, 1, 2, 3].map(i => `<line x1="0" y1="${i * 44}" x2="510" y2="${i * 44}" stroke="${LINE}" stroke-width="1" stroke-dasharray="3 6"/>`).join('')}
      <svg width="510" height="150" viewBox="0 0 510 150" overflow="hidden">
        <path data-dfill d="" fill="${P.main}" opacity="0.1"/>
        <path data-dline d="" fill="none" stroke="${P.main}" stroke-width="2.6" stroke-linecap="round"/>
        <g data-dbuys></g>
        <g data-dmark>
          <circle r="7" fill="${P.main}"/>
          <circle r="7" fill="none" stroke="${P.main}" stroke-width="2" data-dring opacity="0"/>
        </g>
      </svg>
    </g>
    <line x1="66" y1="344" x2="576" y2="344" stroke="${LINE}" stroke-width="2"/>
    ${label(66, 370, 'Our AI buys at the dip — and the saving reaches your price.', { size: 12.5, op: 0.5, weight: 600 })}`;

    return {
      svg: wrap(inner),
      pills: pMK('Buying the dip'),
      init(root) {
        const line = root.querySelector('[data-dline]');
        const fill = root.querySelector('[data-dfill]');
        const mark = root.querySelector('[data-dmark]');
        const ring = root.querySelector('[data-dring]');
        const buys = root.querySelector('[data-dbuys]');
        if (!line) return null;
        const pEl = root.querySelector('[data-role="dprice"]');
        const sEl = root.querySelector('[data-role="dsave"]');
        const N = 34, W = 510, H = 150, lo = 0.5, hi = 1.4;
        const xOf = i => (i / (N - 1)) * W;
        const yOf = v => H - ((v - lo) / (hi - lo)) * (H - 20) - 10;
        let data = series(N, 3);
        let saved = 0;
        const draw = () => {
          const d = data.map((v, i) => `${i ? 'L' : 'M'} ${xOf(i).toFixed(1)} ${yOf(v).toFixed(1)}`).join(' ');
          line.setAttribute('d', d);
          fill.setAttribute('d', `${d} L ${W} ${H} L 0 ${H} Z`);
          const li = N - 1;
          mark.setAttribute('transform', `translate(${xOf(li).toFixed(1)} ${yOf(data[li]).toFixed(1)})`);
        };
        const flash = () => {
          ring.setAttribute('opacity', '0.9');
          ring.setAttribute('r', '7');
          let r = 7;
          const anim = setInterval(() => {
            r += 3;
            ring.setAttribute('r', String(r));
            ring.setAttribute('opacity', String(Math.max(0, 0.9 - (r - 7) / 26)));
            if (r > 32) { clearInterval(anim); ring.setAttribute('opacity', '0'); }
          }, 40);
        };
        const tick = () => {
          const last = data[N - 1];
          let v = last + (Math.random() - 0.5) * 0.2;
          v = Math.max(0.54, Math.min(1.34, v));
          data.push(v); data.shift();
          // buy when we just turned up from a low
          if (data[N - 2] < data[N - 3] && v > data[N - 2] && data[N - 2] < 0.8) {
            flash();
            saved += 0.94 - data[N - 2];
            if (sEl) sEl.textContent = `SAVED $${saved.toFixed(2)}/GB`;
            const g = document.createElementNS('http://www.w3.org/2000/svg', 'g');
            g.setAttribute('transform', `translate(${xOf(N - 2).toFixed(1)} ${(yOf(data[N - 2]) + 20).toFixed(1)})`);
            g.innerHTML = `<rect x="-24" y="-9" width="48" height="19" rx="5" fill="${INK}"/>
              <text y="4.5" text-anchor="middle" font-size="9" font-weight="700" fill="#FFFFFF"
                style="font-family:ui-monospace,Menlo,monospace">$${data[N - 2].toFixed(2)}</text>`;
            buys.appendChild(g);
            while (buys.children.length > 2) buys.removeChild(buys.firstChild);
          }
          [...buys.children].forEach(g => {
            const t = g.getAttribute('transform').match(/translate\(([-\d.]+) ([-\d.]+)\)/);
            if (t) g.setAttribute('transform', `translate(${(+t[1] - W / (N - 1)).toFixed(1)} ${t[2]})`);
          });
          if (pEl) pEl.textContent = `$${v.toFixed(2)}`;
          if (saved > 2.2) saved = 0;
          draw();
        };
        draw();
        const id = setInterval(tick, 820);
        return () => clearInterval(id);
      },
    };
  },
};

/* ══════════════ 3 · ORDER BOOK ══════════════ */
export const orderBook = {
  id: 'mkbook',
  name: 'Order Book',
  family: 'Credibility',
  tagline: 'Bids, asks and the fill in between',
  desc: 'A two-sided ladder: asks above, bids below, quantities flickering, the spread highlighted in the middle and a cyan "our fill" line landing inside it. It is the most technically literal reading of "we trade this market", and the hardest version for a sceptic to dismiss as an illustration.',
  pros: ['The single most credible register available for a trading claim', 'Constant micro-motion in the quantities with no big restarts', 'Compact and sharp; nothing to localise but four labels', 'Distinct from every other panel on the page'],
  cons: ['Requires the most financial literacy of the five', 'Cold — no benefit to the reader stated visually', 'Depth numbers must eventually be real or it invites doubt'],
  scores: { story: 3, motion: 4, perf: 5, mobile: 3, brand: 3, ease: 4 },
  build: (uid) => {
    const asks = [[1.12, 420], [1.06, 610], [1.01, 880], [0.98, 1240]];
    const bids = [[0.92, 1310], [0.88, 940], [0.84, 660], [0.79, 380]];
    const rh = 28;
    const inner = `
    ${dots(uid)}
    ${bloom(320, 230, 200, uid)}
    ${panel(56, 66, 528, 328)}
    ${mono(82, 98, 'OMDM ORDER BOOK · DATA/GB', { size: 9.5, op: 0.4 })}
    ${mono(558, 98, 'DEPTH · TB', { size: 9, op: 0.32, anchor: 'end' })}
    <line x1="82" y1="110" x2="558" y2="110" stroke="${LINE}" stroke-width="1.5"/>
    ${asks.map((a, i) => {
      const y = 132 + i * rh;
      return `
      <rect x="${558 - (a[1] / 1400) * 300}" y="${y - 11}" width="${(a[1] / 1400) * 300}" height="22" rx="4" fill="#EF4444" opacity="0.1"/>
      <text x="82" y="${y + 4}" font-size="12.5" font-weight="700" fill="#DC2626" style="font-family:${MONO}">$${a[0].toFixed(2)}</text>
      ${mono(150, y + 4, 'ASK', { size: 9, op: 0.3 })}
      <text x="558" y="${y + 4}" text-anchor="end" font-size="11.5" font-weight="700" fill="${INK}" opacity="0.5"
        style="font-family:${MONO}" data-bq>${a[1]}</text>`;
    }).join('')}
    <!-- the spread -->
    <g transform="translate(0 ${132 + asks.length * rh + 6})">
      <rect x="82" y="-15" width="476" height="34" rx="9" fill="${P.main}" opacity="0.12"/>
      <rect x="82" y="-15" width="476" height="34" rx="9" fill="none" stroke="${P.main}" stroke-width="2"/>
      ${mono(98, 5, 'OUR FILL', { size: 9.5, op: 0.5, fill: P.deep })}
      <text x="188" y="7" font-size="15" font-weight="700" fill="${P.deep}" style="font-family:${MONO}"><tspan data-role="ofill">$0.94</tspan></text>
      <text x="544" y="6" text-anchor="end" font-size="11" font-weight="700" fill="${P.deep}" opacity="0.8"
        style="font-family:${MONO}"><tspan data-role="ospread">SPREAD $0.06</tspan></text>
    </g>
    ${bids.map((b, i) => {
      const y = 132 + (asks.length + 1) * rh + 18 + i * rh;
      return `
      <rect x="82" y="${y - 11}" width="${(b[1] / 1400) * 300}" height="22" rx="4" fill="${P.main}" opacity="0.12"/>
      <text x="82" y="${y + 4}" font-size="12.5" font-weight="700" fill="${P.deep}" style="font-family:${MONO}">$${b[0].toFixed(2)}</text>
      ${mono(150, y + 4, 'BID', { size: 9, op: 0.3 })}
      <text x="558" y="${y + 4}" text-anchor="end" font-size="11.5" font-weight="700" fill="${INK}" opacity="0.5"
        style="font-family:${MONO}" data-bq>${b[1]}</text>`;
    }).join('')}
    ${label(56, 424, 'We sit on the bid side and fill inside the spread — the difference is your price.', { size: 12, op: 0.45, weight: 600 })}`;

    return {
      svg: wrap(inner),
      pills: pMK('Live book'),
      init(root) {
        const qs = [...root.querySelectorAll('[data-bq]')];
        const fill = root.querySelector('[data-role="ofill"]');
        const spread = root.querySelector('[data-role="ospread"]');
        if (!qs.length) return null;
        const base = qs.map(q => +q.textContent);
        const id = setInterval(() => {
          qs.forEach((q, i) => {
            const v = Math.max(120, Math.round(base[i] * (0.82 + Math.random() * 0.36)));
            q.textContent = String(v);
          });
          const f = (0.90 + Math.random() * 0.07).toFixed(2);
          if (fill) fill.textContent = `$${f}`;
          if (spread) spread.textContent = `SPREAD $0.0${3 + Math.floor(Math.random() * 6)}`;
        }, 620);
        return () => clearInterval(id);
      },
    };
  },
};

/* ══════════════ 4 · YOUR PRICE VS MARKET ══════════════ */
export const vsMarket = {
  id: 'mkvs',
  name: 'Market vs Your Price',
  family: 'Benefit-led',
  tagline: 'The gap is the whole product',
  desc: 'Two lines on one chart: the wholesale market thrashing up and down, and your price running flat and low beneath it. The space between them fills in as you watch and a counter names it — "you are $0.33/GB below market". It is the only option where the benefit to the reader, not the cleverness of the system, is the subject.',
  pros: ['The reader\'s own price is the hero, not our trading', 'The shaded gap is the single clearest way to draw a saving', 'Flat-versus-volatile also implies predictable billing', 'Very light and very legible on a phone'],
  cons: ['Less exciting than a live market tape', 'Implies your price never rises, which the terms must actually support'],
  scores: { story: 5, motion: 4, perf: 5, mobile: 5, brand: 4, ease: 4 },
  build: (uid) => {
    const inner = `
    ${dots(uid)}
    ${bloom(320, 230, 200, uid)}
    ${panel(40, 70, 560, 316)}
    ${mono(66, 104, 'MARKET PRICE VS YOUR PRICE · 24H', { size: 9.5, op: 0.4 })}
    <g transform="translate(66 124)">
      <g><rect width="11" height="11" rx="3" fill="${GRAY}" opacity="0.6"/>${mono(20, 10, 'MARKET', { size: 9.5, op: 0.45 })}</g>
      <g transform="translate(108 0)"><rect width="11" height="11" rx="3" fill="${P.main}"/>${mono(20, 10, 'YOUR PRICE', { size: 9.5, op: 0.45, fill: P.deep })}</g>
    </g>
    <g transform="translate(410 112)">
      <rect width="166" height="34" rx="17" fill="${GREEN_SOFT}"/>
      <text x="83" y="22" text-anchor="middle" font-size="12" font-weight="700" fill="${GREEN_TEXT}"
        style="font-family:${MONO}"><tspan data-role="vgap">$0.33/GB BELOW</tspan></text>
    </g>
    <g transform="translate(66 170)">
      ${[0, 1, 2, 3, 4].map(i => `<line x1="0" y1="${i * 38}" x2="510" y2="${i * 38}" stroke="${LINE}" stroke-width="1" stroke-dasharray="3 6"/>`).join('')}
      <svg width="510" height="160" viewBox="0 0 510 160" overflow="hidden">
        <path data-vgapfill d="" fill="${P.main}" opacity="0.12"/>
        <path data-vmkt d="" fill="none" stroke="${GRAY}" stroke-width="2.4" stroke-linecap="round" opacity="0.75"/>
        <path data-vyou d="" fill="none" stroke="${P.main}" stroke-width="3" stroke-linecap="round"/>
        <g data-vdot><circle r="6" fill="${P.main}"/></g>
      </svg>
    </g>
    <line x1="66" y1="348" x2="576" y2="348" stroke="${LINE}" stroke-width="2"/>
    ${mono(66, 372, 'MARKET', { size: 9, op: 0.35 })}
    <text x="146" y="374" font-size="13" font-weight="700" fill="${INK}" opacity="0.55" style="font-family:${MONO}"><tspan data-role="vm">$0.94</tspan></text>
    ${mono(240, 372, 'YOU PAY', { size: 9, op: 0.35 })}
    <text x="330" y="374" font-size="13" font-weight="700" fill="${P.deep}" style="font-family:${MONO}">$0.61</text>
    ${mono(576, 372, 'FLAT, WHATEVER THE MARKET DOES', { size: 9.5, op: 0.32, anchor: 'end' })}`;

    return {
      svg: wrap(inner),
      pills: pMK('Your price, protected'),
      init(root) {
        const mkt = root.querySelector('[data-vmkt]');
        const you = root.querySelector('[data-vyou]');
        const gap = root.querySelector('[data-vgapfill]');
        const dot = root.querySelector('[data-vdot]');
        if (!mkt) return null;
        const gEl = root.querySelector('[data-role="vgap"]');
        const mEl = root.querySelector('[data-role="vm"]');
        const N = 40, W = 510, H = 160, lo = 0.45, hi = 1.45;
        const xOf = i => (i / (N - 1)) * W;
        const yOf = v => H - ((v - lo) / (hi - lo)) * (H - 22) - 11;
        let data = series(N, 5);
        const YOU = 0.61;
        const draw = () => {
          const dm = data.map((v, i) => `${i ? 'L' : 'M'} ${xOf(i).toFixed(1)} ${yOf(v).toFixed(1)}`).join(' ');
          const dy = data.map((_, i) => `${i ? 'L' : 'M'} ${xOf(i).toFixed(1)} ${yOf(YOU).toFixed(1)}`).join(' ');
          mkt.setAttribute('d', dm);
          you.setAttribute('d', dy);
          gap.setAttribute('d', `${dm} L ${W} ${yOf(YOU).toFixed(1)} L 0 ${yOf(YOU).toFixed(1)} Z`);
          dot.setAttribute('transform', `translate(${W} ${yOf(YOU).toFixed(1)})`);
        };
        const tick = () => {
          const last = data[N - 1];
          let v = last + (Math.random() - 0.5) * 0.22;
          v = Math.max(0.58, Math.min(1.4, v));
          data.push(v); data.shift();
          if (mEl) mEl.textContent = `$${v.toFixed(2)}`;
          if (gEl) gEl.textContent = `$${Math.max(0, v - YOU).toFixed(2)}/GB BELOW`;
          draw();
        };
        draw();
        const id = setInterval(tick, 780);
        return () => clearInterval(id);
      },
    };
  },
};

/* ══════════════ 5 · TICKER TAPE ══════════════ */
export const tape = {
  id: 'mktape',
  name: 'Ticker Tape',
  family: 'Minimal',
  tagline: 'Regional prices, scrolling past',
  desc: 'A horizontal tape of regional wholesale prices scrolls continuously — EU 0.42 ▼, APAC 0.58 ▲, LATAM 0.71 ▼ — above a single headline figure for the average discount. No chart, no card, almost no ink. It is the lightest way to say "this is a live market with many prices in it" and the easiest to keep honest.',
  pros: ['Cheapest of the five in every sense: bytes, paint, build time', 'Many prices at once implies a real market better than one number does', 'Regional names hint at coverage as well as pricing', 'Never restarts — the tape simply keeps moving'],
  cons: ['Least dramatic; no dip, no buy, no story', 'Horizontal scrolling text is easy to ignore', 'Says nothing about what the AI actually does'],
  scores: { story: 3, motion: 4, perf: 5, mobile: 4, brand: 4, ease: 5 },
  build: (uid) => {
    const rows = [
      ['EU · WEST', 0.42, -1], ['EU · EAST', 0.51, 1], ['APAC', 0.58, 1], ['LATAM', 0.71, -1],
      ['MENA', 0.63, -1], ['NORTH AM', 0.47, 1], ['AFRICA', 0.82, -1], ['OCEANIA', 0.55, 1],
    ];
    const one = (offset, shift = 0) => rows.map((rr, ii) => {
      const i = ii; const r = rows[(ii + shift) % rows.length];
      const x = offset + i * 168;
      const up = r[2] > 0;
      return `
      <g transform="translate(${x} 0)">
        <text font-size="12" font-weight="700" fill="${INK}" opacity="0.45" style="font-family:${MONO}">${r[0]}</text>
        <text x="96" font-size="13.5" font-weight="700" fill="${up ? '#DC2626' : P.deep}" style="font-family:${MONO}">$${r[1].toFixed(2)}</text>
        <text x="146" font-size="12" font-weight="700" fill="${up ? '#DC2626' : P.deep}">${up ? '▲' : '▼'}</text>
      </g>`;
    }).join('');
    const inner = `
    ${dots(uid)}
    ${bloom(320, 214, 200, uid)}
    ${mono(40, 56, 'OMDM · WHOLESALE DATA · ALL REGIONS', { size: 10, op: 0.32 })}
    ${[0, 1, 2].map(k => `
      <g transform="translate(0 ${118 + k * 52})">
        <rect x="26" y="-22" width="588" height="40" rx="12" fill="${WHITE}" stroke="${LINE}" stroke-width="1.5"/>
        <svg x="30" y="-22" width="580" height="40" viewBox="0 0 580 40" overflow="hidden">
          <g transform="translate(0 26)">
            <g>
              ${one(0, k * 3)}${one(1344, k * 3)}
              <animateTransform attributeName="transform" type="translate" values="0,0;-1344,0"
                dur="${(26 + k * 5)}s" repeatCount="indefinite" calcMode="linear"/>
            </g>
          </g>
        </svg>
      </g>`).join('')}
    <g transform="translate(40 296)">
      <rect width="272" height="96" rx="18" fill="${INK}"/>
      ${mono(22, 34, 'AVERAGE VS LIST PRICE', { size: 9, fill: WHITE, op: 0.45 })}
      <text x="22" y="76" font-size="38" font-weight="700" fill="${P.main}" style="font-family:${MONO}"><tspan data-role="tpavg">-34%</tspan></text>
    </g>
    <g transform="translate(336 296)">
      <rect width="264" height="96" rx="18" fill="${WHITE}" stroke="${LINE}" stroke-width="1.5"/>
      ${mono(22, 34, 'TRADES IN THE LAST HOUR', { size: 9, op: 0.4 })}
      <text x="22" y="76" font-size="38" font-weight="700" fill="${INK}" style="font-family:${MONO}"><tspan data-role="tptr">1,204</tspan></text>
    </g>
    ${label(40, 428, 'Prices move constantly. Our AI trades them so yours does not have to.', { size: 12, op: 0.45, weight: 600 })}`;

    return {
      svg: wrap(inner),
      pills: pMK('24/7 market'),
      init(root) {
        const avg = root.querySelector('[data-role="tpavg"]');
        const tr = root.querySelector('[data-role="tptr"]');
        let n = 1204;
        const id = setInterval(() => {
          if (avg) avg.textContent = `-${30 + Math.floor(Math.random() * 8)}%`;
          n += 3 + Math.floor(Math.random() * 7);
          if (n > 1400) n = 1180;
          if (tr) tr.textContent = n.toLocaleString('en-US');
        }, 1500);
        return () => clearInterval(id);
      },
    };
  },
};

/* ══ MARKET · 6–9 ═══════════════════════════════════════════════════ */

export const mkYouPaid = {
  id: 'mk-youpaid',
  name: 'What You Actually Paid',
  family: 'Outcome',
  tagline: 'Twelve buys against the market average',
  desc:
    'A market is only interesting if it produces a better price. Twelve purchases are plotted as ' +
    'points against the rolling market average: every one lands below the line, and the total saved ' +
    'is stated at the end. It moves the panel from "look, a market exists" to "here is what the ' +
    'market did for you".',
  pros: [
    'Answers the only question a customer has about a marketplace',
    'Points below a line is the clearest possible visual claim',
    'The cumulative figure gives the panel a payoff',
  ],
  cons: ['Every point below average invites scepticism', 'Needs real fill data to publish'],
  scores: { story: 5, motion: 4, perf: 5, mobile: 4, brand: 5, ease: 4 },
  build: (uid) => {
    const dur = 12;
    const avg = series(26, 11, 0.9, 1.18);
    const buys = [[2, 0.82], [5, 0.74], [8, 0.79], [11, 0.68], [14, 0.72], [17, 0.64],
      [20, 0.7], [23, 0.61]];
    const x0 = 84, x1 = 566, y0 = 330, yTop = 120;
    const px = (i) => x0 + (i / 25) * (x1 - x0);
    const py = (v) => y0 - ((v - 0.5) / 0.8) * (y0 - yTop);
    const inner = `
    ${dots(uid)}
    ${bloom(320, 220, 250, uid)}
    ${mono(72, 56, 'YOUR FILLS vs MARKET AVERAGE \u00b7 \u20ac / GB', { size: 9.5, op: 0.45 })}
    <line x1="${x0}" y1="${y0}" x2="${x1}" y2="${y0}" stroke="${LINE}" stroke-width="2"/>
    ${[0.7, 0.9, 1.1].map((v) => `
      <line x1="${x0}" y1="${py(v).toFixed(0)}" x2="${x1}" y2="${py(v).toFixed(0)}" stroke="${LINE}" stroke-width="1" opacity="0.6"/>
      ${mono(x0 - 10, py(v) + 4, `\u20ac${v.toFixed(2)}`, { size: 8.5, anchor: 'end', op: 0.35 })}`).join('')}
    <polyline points="${avg.map((v, i) => `${px(i).toFixed(0)} ${py(v).toFixed(0)}`).join(' ')}"
      fill="none" stroke="${GRAY}" stroke-width="2.4" stroke-dasharray="6 5"
      stroke-dashoffset="900">
      <animate attributeName="stroke-dashoffset" values="900;0" keyTimes="0;1" dur="${dur * 2}s" repeatCount="indefinite"/>
    </polyline>
    ${mono(x1, py(avg[25]) - 10, 'MARKET AVERAGE', { size: 8.5, anchor: 'end', op: 0.4 })}
    ${buys.map(([i, v], k) => {
      const on = 0.06 + k * 0.08;
      return `<g opacity="0">
        <animate attributeName="opacity" values="0;0;1;1" keyTimes="0;${on.toFixed(3)};${(on + 0.03).toFixed(3)};1"
          dur="${dur}s" repeatCount="indefinite" fill="freeze"/>
        <line x1="${px(i).toFixed(0)}" y1="${py(v).toFixed(0)}" x2="${px(i).toFixed(0)}" y2="${py(avg[i]).toFixed(0)}"
          stroke="${P.main}" stroke-width="1.6" opacity="0.4"/>
        <circle cx="${px(i).toFixed(0)}" cy="${py(v).toFixed(0)}" r="5.5" fill="${P.main}"/>
        ${mono(px(i).toFixed(0), py(v) + 20, `\u20ac${v.toFixed(2)}`, { size: 8, anchor: 'middle', op: 0.5, fill: P.deep })}
      </g>`;
    }).join('')}
    <g opacity="0">
      <animate attributeName="opacity" values="0;0;1;1" keyTimes="0;0.74;0.82;1" dur="${dur}s" repeatCount="indefinite" fill="freeze"/>
      ${card(72, 360, 240, 66, { r: 12, fill: P.wash, stroke: P.main, sw: 2 })}
      ${mono(96, 386, 'EIGHT FILLS, ALL BELOW', { size: 8.5, op: 0.5 })}
      ${num(96, 414, '31% under average', { size: 15, fill: P.deep })}
      ${card(328, 360, 240, 66, { r: 12, fill: WHITE, stroke: LINE })}
      ${mono(352, 386, 'TOTAL SAVED, THIS QUARTER', { size: 8.5, op: 0.4 })}
      ${num(352, 414, '\u20ac2,840', { size: 15 })}
    </g>`;
    return { svg: wrap(inner), pills: pMK('31% under average') };
  },
};

export const mkSpread = {
  id: 'mk-spread',
  name: 'The Spread Closing',
  family: 'Mechanism',
  tagline: 'More sellers, narrower spread, cheaper data',
  desc:
    'The mechanism, in one line: as sellers join, the gap between the best bid and the best ask ' +
    'narrows, and the narrower it gets the less anybody pays. The seller count climbs from four to ' +
    'twenty-two and the spread falls from eleven cents to four. It explains why a market beats a ' +
    'price list, rather than asserting it.',
  pros: [
    'Explains the actual economic mechanism, which is rare and persuasive',
    'One number falling is easy to follow',
    'Gives the page something a competitor cannot simply copy',
  ],
  cons: ['Assumes the reader knows what a spread is', 'Implies growth figures we must be able to show'],
  scores: { story: 5, motion: 5, perf: 5, mobile: 4, brand: 4, ease: 3 },
  build: (uid) => {
    const dur = 12;
    const steps = [[4, 0.11], [7, 0.09], [11, 0.07], [15, 0.06], [19, 0.05], [22, 0.04]];
    const x0 = 96, x1 = 552, y0 = 320, yTop = 130;
    const px = (i) => x0 + (i / 5) * (x1 - x0);
    const py = (v) => y0 - ((v - 0.02) / 0.11) * (y0 - yTop);
    const inner = `
    ${dots(uid)}
    ${bloom(320, 210, 250, uid)}
    ${mono(72, 56, 'SELLERS ON THE BOOK vs SPREAD', { size: 9.5, op: 0.45 })}
    <line x1="${x0}" y1="${y0}" x2="${x1}" y2="${y0}" stroke="${LINE}" stroke-width="2"/>
    <polyline points="${steps.map(([, v], i) => `${px(i).toFixed(0)} ${py(v).toFixed(0)}`).join(' ')}"
      fill="none" stroke="${P.main}" stroke-width="3.4" stroke-dasharray="600" stroke-dashoffset="600">
      <animate attributeName="stroke-dashoffset" values="600;0;0" keyTimes="0;0.62;1" dur="${dur}s" repeatCount="indefinite" fill="freeze"/>
    </polyline>
    ${steps.map(([n, v], i) => {
      const on = 0.06 + i * 0.1;
      return `<g opacity="0">
        <animate attributeName="opacity" values="0;0;1;1" keyTimes="0;${on.toFixed(3)};${(on + 0.04).toFixed(3)};1"
          dur="${dur}s" repeatCount="indefinite" fill="freeze"/>
        <circle cx="${px(i).toFixed(0)}" cy="${py(v).toFixed(0)}" r="5.5" fill="${P.main}"/>
        ${mono(px(i).toFixed(0), py(v) - 14, `\u20ac${v.toFixed(2)}`, { size: 9, anchor: 'middle', op: 0.6, fill: P.deep })}
        ${mono(px(i).toFixed(0), y0 + 22, `${n}`, { size: 9.5, anchor: 'middle', op: 0.45 })}
      </g>`;
    }).join('')}
    ${mono(x0, y0 + 42, 'SELLERS ON THE BOOK', { size: 8.5, op: 0.32 })}
    <g opacity="0">
      <animate attributeName="opacity" values="0;0;1;1" keyTimes="0;0.7;0.78;1" dur="${dur}s" repeatCount="indefinite" fill="freeze"/>
      ${card(72, 376, 496, 54, { r: 12, fill: P.wash, stroke: P.main, sw: 2 })}
      ${label(96, 408, 'Every seller who joins makes the next gigabyte cheaper.', { size: 13.5, fill: P.deep })}
    </g>
    ${mono(72, 112, 'SPREAD, \u20ac / GB', { size: 8.5, op: 0.35 })}`;
    return { svg: wrap(inner), pills: pMK('Spread closing') };
  },
};

export const mkSettled = {
  id: 'mk-settled',
  name: 'Settled',
  family: 'Trust',
  tagline: 'The trade, and the receipt behind it',
  desc:
    'A market without settlement is a chart. One order is followed all the way through — matched, ' +
    'allocated, settled, receipted — with a hash and a timestamp at the end. It answers the question ' +
    'a sceptical buyer asks about any marketplace: what actually happens after the number moves.',
  pros: [
    'Settlement is the part that makes the market real rather than decorative',
    'A hash and timestamp read as auditable',
    'Reuses the audit language already used elsewhere on the site',
  ],
  cons: ['Only lands for a reader who already understands markets', 'Four stages is a lot for one panel'],
  scores: { story: 5, motion: 4, perf: 5, mobile: 5, brand: 5, ease: 4 },
  build: (uid) => {
    const dur = 11;
    const stages = [
      ['Order placed', '2 GB at \u20ac0.64 or better', '14:22:08.114'],
      ['Matched', 'Seller: Orange ES \u00b7 \u20ac0.61', '14:22:08.152'],
      ['Allocated', 'Profile updated on device', '14:22:08.390'],
      ['Settled', 'Receipt written, both sides', '14:22:09.004'],
    ];
    const inner = `
    ${dots(uid)}
    ${bloom(320, 210, 250, uid)}
    ${mono(72, 56, 'ORDER 8841-C \u00b7 END TO END', { size: 9.5, op: 0.45 })}
    ${stages.map(([nm, note, ts], i) => {
      const y = 82 + i * 74;
      const on = 0.06 + i * 0.15;
      return `<g opacity="0">
        <animate attributeName="opacity" values="0;0;1;1" keyTimes="0;${on.toFixed(3)};${(on + 0.05).toFixed(3)};1"
          dur="${dur}s" repeatCount="indefinite" fill="freeze"/>
        ${card(72, y, 496, 60, { r: 12, fill: WHITE, stroke: LINE })}
        <circle cx="102" cy="${y + 30}" r="11" fill="${P.wash}"/>
        <path d="M 96 ${y + 30} l 4.5 4.5 l 8 -9" fill="none" stroke="${P.main}" stroke-width="2.4" stroke-linecap="round"/>
        ${label(130, y + 27, nm, { size: 13.5 })}
        ${mono(130, y + 46, note, { size: 9, op: 0.42 })}
        ${mono(544, y + 36, ts, { size: 9.5, anchor: 'end', op: 0.5, fill: P.deep })}
        ${i < 3 ? `<line x1="102" y1="${y + 60}" x2="102" y2="${y + 74}" stroke="${LINE}" stroke-width="2"/>` : ''}
      </g>`;
    }).join('')}
    <g opacity="0">
      <animate attributeName="opacity" values="0;0;1;1" keyTimes="0;0.74;0.82;1" dur="${dur}s" repeatCount="indefinite" fill="freeze"/>
      ${card(72, 384, 496, 44, { r: 11, fill: P.wash, stroke: P.main, sw: 1.8 })}
      ${mono(96, 412, 'RECEIPT 4f2a\u20228e01 \u00b7 890 ms, ORDER TO SETTLEMENT', { size: 9.5, op: 0.6, fill: P.deep })}
    </g>`;
    return { svg: wrap(inner), pills: pMK('Settled and receipted') };
  },
};

export const mkWhoSells = {
  id: 'mk-whosells',
  name: 'Who Is Selling',
  family: 'Trust',
  tagline: 'Named counterparties, not anonymous liquidity',
  desc:
    'The supply side, named: six carriers and aggregators with the volume each has on the book and ' +
    'the countries they cover. A market whose participants are anonymous is a black box; a market ' +
    'whose sellers are all Tier-1 carriers is an argument for quality as well as price.',
  pros: [
    'Names supply, which turns a price story into a quality story',
    'Consistent with the transparency stance taken on the network pages',
    'A growing list is easy to keep current',
  ],
  cons: ['Requires carrier permission to name them', 'Volume figures are commercially sensitive'],
  scores: { story: 4, motion: 3, perf: 5, mobile: 5, brand: 5, ease: 3 },
  build: (uid) => {
    const dur = 11;
    const sellers = [
      ['Vodafone', '14 countries', 412],
      ['Orange', '11 countries', 338],
      ['Telef\u00f3nica', '9 countries', 296],
      ['T-Mobile', '6 countries', 214],
      ['A1 Telekom', '8 countries', 188],
      ['Telia', '5 countries', 141],
    ];
    const inner = `
    ${dots(uid)}
    ${bloom(320, 210, 250, uid)}
    ${mono(72, 56, 'SUPPLY SIDE \u00b7 TERABYTES ON THE BOOK', { size: 9.5, op: 0.45 })}
    ${sellers.map(([nm, cov, tb], i) => {
      const y = 78 + i * 54;
      const on = 0.06 + i * 0.1;
      return `<g opacity="0">
        <animate attributeName="opacity" values="0;0;1;1" keyTimes="0;${on.toFixed(3)};${(on + 0.045).toFixed(3)};1"
          dur="${dur}s" repeatCount="indefinite" fill="freeze"/>
        ${card(72, y, 496, 44, { r: 11, fill: i % 2 ? '#FAFAFB' : WHITE, stroke: LINE })}
        ${label(96, y + 28, nm, { size: 13.5 })}
        ${mono(232, y + 28, cov, { size: 9, op: 0.4 })}
        <rect x="344" y="${y + 18}" width="${Math.round((tb / 412) * 130)}" height="9" rx="4.5" fill="${P.main}" opacity="0.75"/>
        ${num(544, y + 30, `${tb} TB`, { size: 13, anchor: 'end' })}
      </g>`;
    }).join('')}
    <g opacity="0">
      <animate attributeName="opacity" values="0;0;1;1" keyTimes="0;0.7;0.78;1" dur="${dur}s" repeatCount="indefinite" fill="freeze"/>
      ${card(72, 402, 496, 44, { r: 11, fill: P.wash, stroke: P.main, sw: 1.8 })}
      ${mono(96, 430, 'EVERY SELLER IS A TIER-1 CARRIER \u2014 NO ANONYMOUS LIQUIDITY', { size: 9.5, op: 0.6, fill: P.deep })}
    </g>`;
    return { svg: wrap(inner), pills: pMK('Named sellers') };
  },
};

/* ── registry ── */

export const mkNoSurge = {
  id: 'mk-nosurge',
  name: 'No Surge Pricing',
  family: 'Trust',
  tagline: 'The market moves; your price does not',
  desc:
    'A market panel raises an obvious fear: that the price moves against the customer. This answers ' +
    'it directly — the wholesale line swings through the day while the retail line the customer pays ' +
    'stays flat, with the volatility absorbed on our side. Pre-empting the objection is worth more ' +
    'than another chart of the market itself.',
  pros: [
    'Answers the fear the rest of the panel creates',
    'A flat line against a jagged one needs no caption',
    'Positions us as taking the risk, which is a premium position',
  ],
  cons: ['Commits us to absorbing volatility', 'Slightly undercuts the market narrative'],
  scores: { story: 5, motion: 4, perf: 5, mobile: 5, brand: 5, ease: 4 },
  build: (uid) => {
    const dur = 12;
    const ws = series(30, 19, 0.52, 1.22);
    const x0 = 92, x1 = 560, y0 = 330, yTop = 120;
    const px = (i) => x0 + (i / 29) * (x1 - x0);
    const py = (v) => y0 - ((v - 0.4) / 0.95) * (y0 - yTop);
    const inner = `
    ${dots(uid)}
    ${bloom(320, 220, 250, uid)}
    ${mono(72, 54, 'WHOLESALE vs WHAT YOU PAY \u00b7 \u20ac / GB', { size: 9.5, op: 0.45 })}
    <line x1="${x0}" y1="${y0}" x2="${x1}" y2="${y0}" stroke="${LINE}" stroke-width="2"/>
    <polyline points="${ws.map((v, i) => `${px(i).toFixed(0)} ${py(v).toFixed(0)}`).join(' ')}"
      fill="none" stroke="${GRAY}" stroke-width="2.4" stroke-dasharray="1000" stroke-dashoffset="1000">
      <animate attributeName="stroke-dashoffset" values="1000;0;0" keyTimes="0;0.6;1" dur="${dur}s" repeatCount="indefinite" fill="freeze"/>
    </polyline>
    ${mono(x1, py(ws[29]) - 12, 'WHOLESALE, ALL DAY', { size: 8.5, anchor: 'end', op: 0.42 })}
    <line x1="${x0}" y1="${py(0.79)}" x2="${x1}" y2="${py(0.79)}" stroke="${P.main}" stroke-width="3.6"
      stroke-dasharray="470" stroke-dashoffset="470">
      <animate attributeName="stroke-dashoffset" values="470;0;0" keyTimes="0;0.34;1" dur="${dur}s" repeatCount="indefinite" fill="freeze"/>
    </line>
    ${label(x0 + 10, py(0.79) - 14, 'Your price \u2014 \u20ac0.79, fixed', { size: 13, fill: P.deep })}
    <g opacity="0">
      <animate attributeName="opacity" values="0;0;1;1" keyTimes="0;0.7;0.78;1" dur="${dur}s" repeatCount="indefinite" fill="freeze"/>
      ${card(72, 366, 496, 78, { r: 13, fill: P.wash, stroke: P.main, sw: 2 })}
      ${label(96, 398, 'The market moves thirty times a day.', { size: 14 })}
      ${label(96, 426, 'Your price moves when we lower it, and not before.', { size: 14, fill: P.deep })}
    </g>`;
    return { svg: wrap(inner), pills: pMK('Fixed retail price') };
  },
};

/* ── registry ── */

/* ══ MARKET · 11–15 ═════════════════════════════════════════════════ */

export const mkNightDesk = {
  id: 'mk-night',
  name: 'Night Desk',
  family: 'Dark surface',
  tagline: 'The fills that happened while you were asleep',
  desc:
    'The only dark panel on the page, and the only one that uses a clock instead of a chart axis. ' +
    'Nine buys land between one and six in the morning \u2014 \u20ac0.58, \u20ac0.55, \u20ac0.49 at 03:12 \u2014 with a sweep ' +
    'line crossing the night as they appear. \u201cTrades this market 24/7\u201d is a claim about hours nobody is ' +
    'watching, so it should be drawn in those hours.',
  pros: [
    'Dark ground makes it the one panel on a white page you cannot scroll past',
    'Uses the 24/7 claim literally, which no other option on this board touches',
    'A clock axis is instantly readable without knowing anything about markets',
  ],
  cons: [
    'A dark block needs care not to fight the rest of the light page',
    'The overnight framing is charming but says nothing about price levels',
  ],
  scores: { story: 4, motion: 4, perf: 5, mobile: 4, brand: 3, ease: 4 },
  build: (uid) => {
    const dur = 12;
    const trades = [[0.4, 0.58], [1.1, 0.55], [1.8, 0.62], [2.4, 0.51], [3.2, 0.49],
      [3.9, 0.57], [4.6, 0.53], [5.3, 0.6], [5.8, 0.52]];
    const X = (h) => 30 + (h / 6) * 486;
    const Y = (p) => 246 - ((p - 0.45) / 0.22) * 150;
    const inner = `
    ${dots(uid)}
    ${bloom(320, 210, 240, uid)}
    <g transform="translate(40 56)">
      <rect width="560" height="320" rx="22" fill="${INK}"/>
      <circle cx="30" cy="34" r="5" fill="${P.main}">
        <animate attributeName="opacity" values="1;0.3;1" dur="1.6s" repeatCount="indefinite"/>
      </circle>
      ${mono(46, 38, 'OMDM DESK \u00b7 01:00\u201306:00 CET', { size: 9.5, fill: WHITE, op: 0.5 })}
      <text x="530" y="40" text-anchor="end" font-size="12" font-weight="700" fill="${P.main}"
        style="font-family:${MONO}">9 FILLS WHILE YOU SLEPT</text>
      ${[0, 1, 2, 3].map((i) => `<line x1="30" y1="${96 + i * 50}" x2="516" y2="${96 + i * 50}"
        stroke="${WHITE}" stroke-width="1" opacity="0.07"/>`).join('')}
      <line x1="30" y1="246" x2="516" y2="246" stroke="${WHITE}" stroke-width="1.5" opacity="0.18"/>
      ${trades.map(([h, p], i) => {
        const x = X(h).toFixed(0);
        const y = Y(p).toFixed(0);
        const yl = (Y(p) - 13).toFixed(0);
        const on = 0.06 + i * 0.09;
        return `<g opacity="0">
          <animate attributeName="opacity" values="0;0;1;1" keyTimes="0;${on.toFixed(3)};${(on + 0.03).toFixed(3)};1"
            dur="${dur}s" repeatCount="indefinite" fill="freeze"/>
          <line x1="${x}" y1="${y}" x2="${x}" y2="246" stroke="${P.main}" stroke-width="1.6" opacity="0.32"/>
          <circle cx="${x}" cy="${y}" r="5" fill="${P.main}"/>
          <text x="${x}" y="${yl}" text-anchor="middle" font-size="9.5" font-weight="700" fill="${P.main}"
            style="font-family:${MONO}">\u20ac${p.toFixed(2)}</text>
        </g>`;
      }).join('')}
      ${[0, 1, 2, 3, 4, 5, 6].map((i) =>
        mono(X(i).toFixed(0), 266, '0' + i + ':00', { size: 8.5, anchor: 'middle', fill: WHITE, op: 0.3 })).join('')}
      <g>
        <line x1="30" y1="76" x2="30" y2="252" stroke="${P.main}" stroke-width="1.5" opacity="0.5"/>
        <animateTransform attributeName="transform" type="translate" values="0,0;486,0" dur="${dur}s"
          repeatCount="indefinite"/>
      </g>
      ${mono(30, 300, 'AVERAGE FILL \u20ac0.54 \u00b7 LOWEST \u20ac0.49 AT 03:12 \u00b7 NOBODY AWAKE', { size: 9, fill: WHITE, op: 0.42 })}
    </g>
    ${label(40, 412, 'The market never closes, so the desk does not either.', { size: 15 })}
    ${mono(40, 440, 'NINE OF TODAY\u2019S FOUR THOUSAND PURCHASES \u00b7 ALL BEFORE BREAKFAST', { size: 9, op: 0.34 })}`;
    return { svg: wrap(inner), pills: pMK('Overnight fills') };
  },
};

export const mkPassThrough = {
  id: 'mk-passthrough',
  name: 'Where It Goes',
  family: 'Mechanism',
  tagline: 'The saving, split in public',
  desc:
    'The question a market panel raises and never answers: if you buy cheaper, do I see it? A single ' +
    'block \u2014 \u20ac0.36 saved against list, per gigabyte \u2014 forks into a wide cyan band worth \u20ac0.29 that ' +
    'goes into the customer\u2019s price and a thin grey one worth \u20ac0.07 that we keep. Publishing the split ' +
    'is a stronger claim than publishing the saving.',
  pros: [
    'Answers the trust question the rest of the board leaves hanging',
    'A wide band against a thin one carries the ratio without reading a number',
    'Commercially specific in a way competitors will not copy',
  ],
  cons: [
    'Publishing a margin, even as a ratio, is a commercial decision above design',
    'The split has to hold every month or the panel becomes a liability',
  ],
  scores: { story: 5, motion: 3, perf: 5, mobile: 4, brand: 4, ease: 4 },
  build: (uid) => {
    const dur = 11;
    const inner = `
    ${dots(uid)}
    ${bloom(320, 220, 240, uid)}
    ${mono(56, 58, 'WHAT THE DESK SAVED LAST MONTH, AND WHERE IT WENT', { size: 9.5, op: 0.45 })}
    <rect x="56" y="186" width="188" height="76" rx="12" fill="${INK}"/>
    ${mono(76, 216, 'SAVED AGAINST LIST', { size: 8.5, fill: WHITE, op: 0.45 })}
    <text x="76" y="248" font-size="26" font-weight="700" fill="${P.main}" style="font-family:${MONO}">\u20ac0.36</text>
    ${mono(180, 248, '/GB', { size: 10, fill: WHITE, op: 0.4 })}
    <path d="M 244 208 C 330 208 344 148 424 148 L 560 148" fill="none" stroke="${P.main}" stroke-width="56"
      opacity="0.92" stroke-dasharray="430" stroke-dashoffset="430">
      <animate attributeName="stroke-dashoffset" values="430;430;0;0" keyTimes="0;0.08;0.46;1" dur="${dur}s"
        repeatCount="indefinite" fill="freeze"/>
    </path>
    <path d="M 244 248 C 330 248 344 312 424 312 L 560 312" fill="none" stroke="${GRAY}" stroke-width="14"
      opacity="0.45" stroke-dasharray="430" stroke-dashoffset="430">
      <animate attributeName="stroke-dashoffset" values="430;430;0;0" keyTimes="0;0.08;0.46;1" dur="${dur}s"
        repeatCount="indefinite" fill="freeze"/>
    </path>
    <g opacity="0">
      <animate attributeName="opacity" values="0;0;1;1" keyTimes="0;0.48;0.56;1" dur="${dur}s"
        repeatCount="indefinite" fill="freeze"/>
      ${mono(544, 112, 'INTO YOUR PRICE \u00b7 81%', { size: 9, anchor: 'end', op: 0.55, fill: P.deep })}
      <text x="544" y="160" text-anchor="end" font-size="30" font-weight="700" fill="${WHITE}"
        style="font-family:${MONO}">\u20ac0.29</text>
      ${mono(544, 292, 'KEPT BY US \u00b7 19%', { size: 9, anchor: 'end', op: 0.4 })}
      <text x="544" y="344" text-anchor="end" font-size="18" font-weight="700" fill="${INK}" opacity="0.5"
        style="font-family:${MONO}">\u20ac0.07</text>
    </g>
    <g opacity="0">
      <animate attributeName="opacity" values="0;0;1;1" keyTimes="0;0.64;0.72;1" dur="${dur}s"
        repeatCount="indefinite" fill="freeze"/>
      ${card(56, 374, 528, 62, { r: 13, fill: P.wash, stroke: P.main, sw: 2 })}
      ${label(80, 412, 'Four fifths of every cent the desk saves leaves our hands.', { size: 14.5, fill: P.deep })}
    </g>`;
    return { svg: wrap(inner), pills: pMK('81% passed through') };
  },
};

export const mkInApp = {
  id: 'mk-inapp',
  name: 'In The App',
  family: 'Product surface',
  tagline: 'Your rate, and the four trades that set it',
  desc:
    'The market from the customer\u2019s side of the glass: an app screen showing \u20ac0.61/GB for the month, ' +
    '22% under list, and the trades behind it \u2014 40 GB from Orange ES at 03:12 for \u20ac0.49, three more ' +
    'beneath. Everything else on this board describes a market; this shows the screen where a customer ' +
    'would check it.',
  pros: [
    'Turns an abstract market into a feature somebody can open and read',
    'Named counterparties and timestamps make the rate checkable',
    'Gives sales a screenshot rather than a diagram',
  ],
  cons: [
    'Promises a screen the app does not have yet',
    'Showing per-trade prices exposes wholesale rates to competitors',
  ],
  scores: { story: 5, motion: 3, perf: 5, mobile: 5, brand: 5, ease: 3 },
  build: (uid) => {
    const dur = 11;
    const rows = [
      ['03:12', 'Orange ES', '40 GB', '\u20ac0.49'],
      ['05:48', 'Vodafone DE', '25 GB', '\u20ac0.54'],
      ['09:20', 'Telef\u00f3nica ES', '60 GB', '\u20ac0.57'],
      ['11:02', 'A1 Telekom AT', '18 GB', '\u20ac0.61'],
    ];
    const inner = `
    ${dots(uid)}
    ${bloom(320, 210, 240, uid)}
    ${card(56, 62, 528, 336, { r: 20, fill: WHITE, stroke: LINE, sw: 2 })}
    <rect x="58" y="64" width="524" height="50" rx="18" fill="${P.wash}"/>
    <rect x="58" y="96" width="524" height="18" fill="${P.wash}"/>
    ${mono(80, 94, 'OPENLINE \u00b7 DATA', { size: 9.5, op: 0.55, fill: P.deep })}
    ${mono(560, 94, 'UPDATED 3 s AGO', { size: 8.5, anchor: 'end', op: 0.4 })}
    ${mono(80, 148, 'YOUR RATE THIS MONTH', { size: 8.5, op: 0.4 })}
    <text x="80" y="186" font-size="34" font-weight="700" fill="${INK}" style="font-family:${MONO}">\u20ac0.61</text>
    ${label(178, 186, '/GB', { size: 14, op: 0.42 })}
    <g transform="translate(430 154)">
      <rect width="130" height="34" rx="17" fill="${GREEN_SOFT}"/>
      <text x="65" y="23" text-anchor="middle" font-size="11.5" font-weight="700" fill="${GREEN_TEXT}"
        style="font-family:${MONO}">22% UNDER LIST</text>
    </g>
    <line x1="80" y1="208" x2="560" y2="208" stroke="${LINE}" stroke-width="1.5"/>
    ${mono(80, 232, 'BOUGHT FOR YOU TODAY', { size: 8.5, op: 0.4 })}
    ${rows.map(([t, who, vol, price], i) => {
      const y = 262 + i * 34;
      const on = 0.1 + i * 0.1;
      return `<g opacity="0">
        <animate attributeName="opacity" values="0;0;1;1" keyTimes="0;${on.toFixed(3)};${(on + 0.05).toFixed(3)};1"
          dur="${dur}s" repeatCount="indefinite" fill="freeze"/>
        ${mono(80, y, t, { size: 10.5, op: 0.45 })}
        ${label(148, y, who, { size: 13, op: 0.85 })}
        ${mono(390, y, vol, { size: 10.5, anchor: 'end', op: 0.45 })}
        ${num(560, y, price, { size: 13, anchor: 'end' })}
        <line x1="80" y1="${y + 12}" x2="560" y2="${y + 12}" stroke="${LINE}" stroke-width="1"/>
      </g>`;
    }).join('')}
    <g opacity="0">
      <animate attributeName="opacity" values="0;0;1;1" keyTimes="0;0.62;0.7;1" dur="${dur}s"
        repeatCount="indefinite" fill="freeze"/>
      ${label(56, 428, 'Every trade that set your rate, on the day it happened.', { size: 14.5, fill: P.deep })}
    </g>`;
    return { svg: wrap(inner), pills: pMK('Visible to the customer') };
  },
};

export const mkLikeMarkets = {
  id: 'mk-likemarkets',
  name: 'Like Electricity',
  family: 'Analogy',
  tagline: 'Three markets that reprice all day',
  desc:
    'Nobody has to be taught that electricity and airline seats are priced by the minute. Three small ' +
    'panels put those two beside wholesale data, each with its own jagged price line and how often it ' +
    'moves \u2014 48 prices a day, thousands a day, continuously. The third is ours, and the difference is ' +
    'who is standing in the market: the customer, or us.',
  pros: [
    'Borrows understanding the reader already has instead of teaching a new idea',
    'Three small charts read faster than one large one',
    'Gives the section a line a salesperson can repeat verbatim',
  ],
  cons: [
    'Comparing ourselves to electricity pricing invites the association with price spikes',
    'Overlaps the fixed-price argument the board already makes elsewhere',
  ],
  scores: { story: 4, motion: 3, perf: 5, mobile: 4, brand: 4, ease: 5 },
  build: (uid) => {
    const dur = 10;
    const cols = [
      { t: 'Electricity', s: 'SPOT, HALF-HOURLY', f: '48 prices a day', who: 'YOU ABSORB IT', seed: 9, on: false },
      { t: 'Airline seats', s: 'REPRICED ON DEMAND', f: 'thousands a day', who: 'YOU ABSORB IT', seed: 21, on: false },
      { t: 'Mobile data', s: 'OMDM \u00b7 WHOLESALE', f: 'traded continuously', who: 'WE ABSORB IT', seed: 5, on: true },
    ];
    const inner = `
    ${dots(uid)}
    ${bloom(320, 210, 240, uid)}
    ${mono(56, 58, 'THREE MARKETS THAT REPRICE ALL DAY', { size: 9.5, op: 0.45 })}
    ${cols.map((c, i) => {
      const x = 56 + i * 180;
      const pts = series(22, c.seed, 0.5, 1.3);
      const poly = pts.map((v, k) => {
        const px = (x + 22 + (k / 21) * 124).toFixed(1);
        const py = (232 - (v - 0.5) * 100).toFixed(1);
        return px + ' ' + py;
      }).join(' ');
      const on = 0.08 + i * 0.12;
      return `<g opacity="0">
        <animate attributeName="opacity" values="0;0;1;1" keyTimes="0;${on.toFixed(3)};${(on + 0.06).toFixed(3)};1"
          dur="${dur}s" repeatCount="indefinite" fill="freeze"/>
        ${card(x, 92, 168, 240, { r: 16, fill: c.on ? P.wash : WHITE, stroke: c.on ? P.main : LINE, sw: c.on ? 2 : 1.5 })}
        ${label(x + 22, 126, c.t, { size: 15, fill: c.on ? P.deep : INK })}
        ${mono(x + 22, 146, c.s, { size: 8, op: 0.4 })}
        <polyline points="${poly}" fill="none" stroke="${c.on ? P.main : GRAY}" stroke-width="2.2"
          stroke-linecap="round" opacity="${c.on ? 1 : 0.65}"/>
        <line x1="${x + 22}" y1="252" x2="${x + 146}" y2="252" stroke="${LINE}" stroke-width="1.2"/>
        ${mono(x + 22, 276, 'MOVES', { size: 8, op: 0.35 })}
        ${label(x + 22, 298, c.f, { size: 12.5, op: 0.8 })}
        ${mono(x + 22, 320, c.who, { size: 8.5, op: c.on ? 0.65 : 0.4, fill: c.on ? P.deep : INK })}
      </g>`;
    }).join('')}
    <g opacity="0">
      <animate attributeName="opacity" values="0;0;1;1" keyTimes="0;0.6;0.68;1" dur="${dur}s"
        repeatCount="indefinite" fill="freeze"/>
      ${card(56, 356, 528, 76, { r: 14, fill: WHITE, stroke: LINE })}
      ${label(80, 390, 'You already buy things priced by the minute.', { size: 14.5 })}
      ${label(80, 416, 'This is the one where somebody stands in the market for you.', { size: 14.5, fill: P.deep })}
    </g>`;
    return { svg: wrap(inner), pills: pMK('A market you know') };
  },
};

export const mkThousands = {
  id: 'mk-thousands',
  name: 'Thousands Daily',
  family: 'Scale',
  tagline: 'One square per purchase',
  desc:
    'The section claims thousands of purchases a day and nothing on the page shows what that looks ' +
    'like. Two hundred and sixty-four squares fill in column by column, each one a real buy, tinted by ' +
    'region \u2014 and the caption admits this is only part of today\u2019s four thousand. No chart, no price, no ' +
    'ladder: just the rate of work made visible.',
  pros: [
    'Quantity is the one claim on this board that has never been drawn',
    'A field of squares is unlike anything else on the page or the board',
    'Cheap to render and reads instantly at any width',
  ],
  cons: [
    'Says nothing about price, saving, or benefit to the reader',
    'Decorative if the count ever stops being true',
    'The region tints need a legend to mean anything',
  ],
  scores: { story: 3, motion: 4, perf: 5, mobile: 4, brand: 4, ease: 5 },
  build: (uid) => {
    const dur = 8;
    const COLS = 24, ROWS = 11, cell = 22, x0 = 64, y0 = 104;
    const tints = [
      { c: P.main, op: 0.95, t: 'EU WEST' },
      { c: P.deep, op: 0.9, t: 'EU EAST' },
      { c: P.main, op: 0.5, t: 'APAC' },
      { c: P.soft, op: 1, t: 'AMERICAS' },
    ];
    const inner = `
    ${dots(uid)}
    ${bloom(320, 210, 240, uid)}
    ${mono(64, 58, 'EVERY SQUARE IS ONE PURCHASE THE DESK MADE TODAY', { size: 9.5, op: 0.45 })}
    ${mono(584, 58, '264 OF 4,182', { size: 9.5, anchor: 'end', op: 0.4, fill: P.deep })}
    ${Array.from({ length: COLS }, (_, c) => {
      const on = 0.02 + c * 0.026;
      const sq = Array.from({ length: ROWS }, (_, r) => {
        const t = tints[(c * 7 + r * 13 + ((c * r) % 5)) % 4];
        const x = x0 + c * cell;
        const y = y0 + r * cell;
        return `<rect x="${x}" y="${y}" width="15" height="15" rx="3.5" fill="${t.c}" opacity="${t.op}"/>`;
      }).join('');
      return `<g opacity="0">
        <animate attributeName="opacity" values="0;0;1;1" keyTimes="0;${on.toFixed(3)};${(on + 0.02).toFixed(3)};1"
          dur="${dur}s" repeatCount="indefinite" fill="freeze"/>
        ${sq}
      </g>`;
    }).join('')}
    ${tints.map((t, i) => {
      const x = 64 + i * 134;
      return `<rect x="${x}" y="${368}" width="11" height="11" rx="3" fill="${t.c}" opacity="${t.op}"/>
        ${mono(x + 20, 378, t.t, { size: 8.5, op: 0.4 })}`;
    }).join('')}
    ${label(64, 414, 'The desk made four thousand of these today.', { size: 15 })}
    ${mono(64, 440, 'ELEVEN REGIONS \u00b7 NONE OF THEM PRICED BY HAND', { size: 9, op: 0.34 })}`;
    return { svg: wrap(inner), pills: pMK('4,182 buys today') };
  },
};

/* ── registry ── */
export const MARKET_VARIANTS = [mkCurrent, candles, dipHunter, orderBook, vsMarket, tape, mkYouPaid, mkSpread, mkSettled, mkWhoSells, mkNoSurge, mkNightDesk, mkPassThrough, mkInApp, mkLikeMarkets, mkThousands];
